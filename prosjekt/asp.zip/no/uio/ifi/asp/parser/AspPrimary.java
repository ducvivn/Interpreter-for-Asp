package no.uio.ifi.asp.parser;

import no.uio.ifi.asp.main.Main;
import no.uio.ifi.asp.runtime.RuntimeReturnValue;
import no.uio.ifi.asp.runtime.RuntimeScope;
import no.uio.ifi.asp.runtime.RuntimeValue;
import no.uio.ifi.asp.scanner.Scanner;

import java.util.ArrayList;

import static no.uio.ifi.asp.scanner.TokenKind.leftBracketToken;
import static no.uio.ifi.asp.scanner.TokenKind.leftParToken;

public class AspPrimary extends AspSyntax {
	AspAtom atom;
	ArrayList<AspPrimarySuffix> aps = new ArrayList<>();
	
	AspPrimary(int n) {
		super(n);
	}
	
	
	public static AspPrimary parse(Scanner s) {
		enterParser("primary");
		
		AspPrimary ap = new AspPrimary(s.curLineNum());
		
		ap.atom = AspAtom.parse(s); // start atom
		
		// valgfri, flere primary suffix
		while (s.curToken().kind == leftParToken || s.curToken().kind == leftBracketToken) {
			ap.aps.add(AspPrimarySuffix.parse(s));
		}
		
		leaveParser("primary");
		return ap;
	}
	
	
	@Override
	public void prettyPrint() {
		atom.prettyPrint();
		for (AspPrimarySuffix ap : aps) {
			ap.prettyPrint();
		}
	}
	
	
	@Override
	public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
		RuntimeValue value = atom.eval(curScope);
		
		for (AspPrimarySuffix ps : aps) {
			
			if (ps instanceof AspArguments) {
				// idk - del 4 kanskje
			}
			else if (ps instanceof AspSubscription) {
				value = value.evalSubscription(ps.eval(curScope), this);
			}
			else Main.panic("Illegal primary suffix " + ps + "!");
		}

		return value;
	}
}
