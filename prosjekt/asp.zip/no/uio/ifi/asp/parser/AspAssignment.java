package no.uio.ifi.asp.parser;

import no.uio.ifi.asp.runtime.RuntimeReturnValue;
import no.uio.ifi.asp.runtime.RuntimeScope;
import no.uio.ifi.asp.runtime.RuntimeValue;
import no.uio.ifi.asp.scanner.Scanner;
import no.uio.ifi.asp.scanner.TokenKind;

import java.util.ArrayList;

public class AspAssignment extends AspSmallStmt {
	AspName name;
	ArrayList<AspSubscription> subscriptions = new ArrayList<>();
	AspExpr expr;
	
	AspAssignment(int n) {
		super(n);
	}
	
	public static AspAssignment parse(Scanner s) {
		enterParser("assignment");
		
		AspAssignment aa = new AspAssignment(s.curLineNum());
		
		aa.name = AspName.parse(s); // start uttrykk
		
		// subscription valgfri, sjekk flere
		while (s.curToken().kind != TokenKind.equalToken) {
			aa.subscriptions.add(AspSubscription.parse(s));
		}
		
		skip(s, TokenKind.equalToken); // sjekk =
		aa.expr = AspExpr.parse(s); // slutt uttrykk
		
		leaveParser("assignment");
		return aa;
	}
	
	
	@Override
	public void prettyPrint() {
		name.prettyPrint();
		
		for (AspSubscription subscription : subscriptions)
			subscription.prettyPrint();
		
		prettyWrite(" "+TokenKind.equalToken.toString()+" ");
		expr.prettyPrint();
	}
	
	
	@Override
	public RuntimeValue eval(RuntimeScope curScope) throws RuntimeReturnValue {
		//-- Must be changed in part 4 ?
		return null;
	}
	
}
